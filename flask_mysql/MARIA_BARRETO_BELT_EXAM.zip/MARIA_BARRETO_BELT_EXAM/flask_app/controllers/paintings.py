from flask import flash, redirect, render_template, url_for, request, session

from flask_app import app
from flask_app.models.paintings import Paintings
from flask_app.models.users import User


@app.route('/paintings/')
def paintings():
    paintings = Paintings.get_all()
    print(paintings)
    return render_template("paintings.html", all_paintings = paintings)


@app.route('/new_painting/')
def new_painting():
    
    return render_template("/new_paint.html")

#para add_painting
@app.route('/add_painting/', methods=["POST"])
def add_painting():
    
    if 'user' not in session:  # Verificar si el usuario no está en la sesión
        flash("Usted no ha iniciado sesión", "error")

    errores = Paintings.validate(request.form)
    if len(errores) > 0:
        for error in errores:
            flash(error, "error")
        return redirect("/new_painting")
        
    
    Paintings.save(request.form)
    flash("Paint added succesfully", "success")
    
    return redirect('/paintings/')

#Obtener todos los datos de la pintura a traves del id 
@app.route('/paintings/<int:id>')
def get_by_id(id):
    paint = Paintings.get_by_id(id)
    if paint:
        return render_template("paint_detalle.html", paint=paint)
    else:
        # Manejar el caso en el que no se encuentre la pintura por el ID
        flash("Paint not found", "danger")
        return redirect("/paintings/")

#es para eliminar de forma segura
@app.route('/paintings/delete_painting/<int:id>')
def delete_painting(id):
    print("Paint that is going to be delete", id)
    Paintings.delete(id)
    flash("The paint has been  deleted", "success")
    return redirect("/paintings/")

#es para editar toda la info de la pintura a traves del id
@app.route('/paintings/edit_paint/<int:id>')
def edit_paint(id):
    edit_paint = Paintings.get_by_id(id)
    if edit_paint:
        return render_template("edit_paint.html", edit_paint=edit_paint)
    else:
        flash("Paint not found", "danger")
        return redirect("/paintings")
@app.route('/paintings/edit/<int:id>', methods=["POST"])
def edit_by_id(id):
    data = {
        "id": id,
        "title": request.form["title"],
        "description": request.form["description"],
        "price": request.form["price"]
    }
    Paintings.update(data)
    flash("The paint has been edited", "success")
    return redirect("/paintings/")