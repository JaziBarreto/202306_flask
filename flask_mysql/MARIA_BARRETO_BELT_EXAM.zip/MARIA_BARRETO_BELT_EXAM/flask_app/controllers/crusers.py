from flask import flash, redirect, render_template, url_for, request, session

from flask_app import app
from flask_app.models.users import User
from flask_app.controllers.paintings import Paintings

from flask_bcrypt import Bcrypt        
bcrypt = Bcrypt(app)  


@app.route('/')
def inicio():
    if'user' not in session:  # Verificar si el usuario no está en la sesión
        flash("Usted no ha iniciado sesión", "error")
        return render_template("/index.html")

#pal registro
@app.route('/create_user', methods=["POST"])
def create_user():
    # Obtener datos del formulario
    first_name = request.form["first_name"]
    last_name = request.form["last_name"]
    email = request.form["email"]
    password = request.form["password"]
    confirm_password = request.form["confirm_password"]

    # Validar caracteres
    if len(first_name) < 2 or len(last_name) < 2:
        flash("El nombre y apellido deben tener al menos 2 caracteres", "error")
        return redirect(url_for('inicio'))

    # Validar las condiciones de contraseña
    if len(password) < 8:
        flash("La contraseña debe tener al menos 8 caracteres", "error")
        return redirect(url_for('inicio'))

    if password != confirm_password:
        flash("Las contraseñas no coinciden", "error")
        return redirect(url_for('inicio'))

    # Hash de la contraseña
    hashed_password = bcrypt.generate_password_hash(password)

    # Si todas las validaciones pasan, guardar el usuario
    data = {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "password": hashed_password
    }
    User.save(data)
    flash("Usuario creado exitosamente", "success")
    return redirect('/paintings/')

#pa iniciar sesion
@app.route('/procesar_login', methods=["POST"])
def procesar_login():
    print(request.form)

    user = User.get_by_email(request.form['login_email'])
    if not user:
        flash("El correo o la contraseña introducidos no son válidos", "error")
        return redirect(url_for('inicio'))

    resultado = bcrypt.check_password_hash(user.password, request.form['login_password'])
    if resultado:
        session['user'] = {
        'id': user.id,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'email': user.email
        }
        return redirect ("/paintings/")
    
    flash("La contraseña o el correo introducidos no son válidos", "error")
    return redirect(url_for('inicio'))


#pa salir
@app.route('/salir') 
def salir():

    session.clear()
    return redirect("/")