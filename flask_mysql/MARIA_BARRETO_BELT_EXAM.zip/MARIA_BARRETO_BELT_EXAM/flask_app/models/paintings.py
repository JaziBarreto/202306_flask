import os

from flask_app.config.mysqlconnection import connectToMySQL

from flask_app.models.users import User
from flask import session

class Paintings:
    def __init__(self, data) -> None:
        self.id = data['id']
        self.title = data['title']
        self.description = data['description']
        self.price = data['price']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']
        self.author = {'first_name': data.get('first_name', ''), 'last_name': data.get('last_name', '')}

#valida los datos que envia el user
    @classmethod
    def validate(cls, formulario):
        errores = []

        if len(formulario['title']) < 2:
            errores.append(
                "El titulo debe tener al menos 2 caracteres"
            )

        if len(formulario['description']) < 10:
            errores.append(
                "La descripcion debe tener al menos 10 caracteres"
            )

        if not formulario['price'].isdigit() or int(formulario['price']) <= 0:
            errores.append("El monto debe ser un número mayor que 0")

        return errores

#retorna todas las pinturas
    @classmethod
    def get_all(cls):
        resultados_instancias = []
        query = "SELECT paintings.*, users.first_name, users.last_name FROM paintings LEFT JOIN users ON paintings.user_id = users.id"
        resultados = connectToMySQL(os.getenv('DATABASE')).query_db(query)
        print("ACA EEEEEEEEEES", resultados)
        for resultado in resultados:
            instancia = cls(resultado)
            resultados_instancias.append(instancia)
        return resultados_instancias

#guarda los datos de la nueva pintura en la base de datos
    @classmethod
    def save(cls, data):
        # Get the user ID from the session
        user_id = session.get('user', {}).get('id')

        if user_id is None:
            raise ValueError("User ID not found in the session.")

        query = "INSERT INTO paintings (`title`, `price`, `description`, `user_id`,`created_at`,`updated_at` ) VALUES (%(title)s, %(price)s, %(description)s, %(user_id)s, NOW(), NOW() );"
        data_with_user_id = {
            'title': data['title'],
            'price': data['price'],
            'description': data['description'],
            'user_id': user_id,
        }

        return connectToMySQL(os.getenv('DATABASE')).query_db(query, data_with_user_id)

#obtiene los datos de la pintura por su id
    @classmethod
    def get_by_id(cls, id ):
        query = "SELECT * FROM paintings LEFT JOIN users ON paintings.user_id = users.id  WHERE paintings.id = %(id)s;"
        data = { 'id': id }
        resultados = connectToMySQL(os.getenv('DATABASE')).query_db( query, data ) 

        paint = cls(resultados[0])
        return paint

#Elimina los datos de una pintura por su id
    @classmethod
    def delete(cls, id ):
        query = "DELETE FROM paintings WHERE id = %(id)s;"
        data = { 'id': id }
        connectToMySQL(os.getenv('DATABASE')).query_db( query, data )
        return True

#Actualiza los datos de una pintura por su id
    @classmethod
    def update(cls, data ):
        query = "UPDATE paintings SET `title` = %(title)s, `price` = %(price)s, `description` = %(description)s WHERE (`id` = %(id)s);"
        connectToMySQL(os.getenv('DATABASE')).query_db( query, data )
        return True
    